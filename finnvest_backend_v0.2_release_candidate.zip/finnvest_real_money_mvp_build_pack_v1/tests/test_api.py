import json, os, tempfile, threading, unittest, urllib.request, urllib.error
from http.server import ThreadingHTTPServer
from pathlib import Path

TMP = tempfile.TemporaryDirectory()
os.environ['FINNVEST_DB'] = str(Path(TMP.name) / 'test.sqlite3')
from backend import server

class FinnvestAPITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        server.init_db()
        cls.http = ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        cls.thread = threading.Thread(target=cls.http.serve_forever, daemon=True); cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.http.server_port}'
    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown(); cls.http.server_close(); TMP.cleanup()
    def request(self, method, path, data=None, token=None, idem=None):
        body = None if data is None else json.dumps(data).encode()
        headers = {'Content-Type':'application/json'}
        if token: headers['Authorization'] = 'Bearer ' + token
        if idem: headers['Idempotency-Key'] = idem
        req=urllib.request.Request(self.base+path, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=3) as r: return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
    def test_health_is_simulation_only(self):
        code, body = self.request('GET','/health'); self.assertEqual(code,200); self.assertEqual(body['mode'],'simulation-only')
    def test_register_login_me_and_eligibility(self):
        code, body = self.request('POST','/v1/auth/register',{'email':'test@example.com','password':'Correct-Horse-123!'})
        self.assertEqual(code,201); token=body['access_token']; self.assertEqual(body['user']['kyc_status'],'not_started')
        code, me = self.request('GET','/v1/me',token=token); self.assertEqual(code,200); self.assertEqual(me['user']['email'],'test@example.com')
        code, elig = self.request('GET','/v1/eligibility',token=token); self.assertEqual(code,200); self.assertFalse(elig['eligible']); self.assertFalse(elig['real_money_enabled'])
        code, login = self.request('POST','/v1/auth/login',{'email':'test@example.com','password':'Correct-Horse-123!'})
        self.assertEqual(code,200); self.assertTrue(login['access_token'])
    def test_short_password_rejected(self):
        code, _ = self.request('POST','/v1/auth/register',{'email':'short@example.com','password':'short'})
        self.assertEqual(code,400)
    def test_sandbox_deposit_is_idempotent_and_balanced(self):
        _, reg = self.request('POST','/v1/auth/register',{'email':'ledger@example.com','password':'Long-Enough-Password-77'})
        token=reg['access_token']
        code, entry = self.request('POST','/v1/sandbox/deposit',{'asset':'USD','amount_minor':2500},token,'deposit-1')
        self.assertEqual(code,201); self.assertTrue(entry['simulation'])
        code, replay = self.request('POST','/v1/sandbox/deposit',{'asset':'USD','amount_minor':2500},token,'deposit-1')
        self.assertEqual(code,200); self.assertTrue(replay['idempotent_replay']); self.assertEqual(entry['entry_id'],replay['entry_id'])
        with server.connect() as db:
            rows=db.execute('SELECT amount_minor FROM postings WHERE entry_id=?',(entry['entry_id'],)).fetchall()
            self.assertEqual(len(rows),2); self.assertEqual(sum(r['amount_minor'] for r in rows),0)
    def test_idempotency_key_payload_mismatch_rejected(self):
        _, reg = self.request('POST','/v1/auth/register',{'email':'idem@example.com','password':'Long-Enough-Password-77'})
        token=reg['access_token']
        code, _ = self.request('POST','/v1/sandbox/deposit',{'asset':'USD','amount_minor':2500},token,'same-key')
        self.assertEqual(code,201)
        code, body = self.request('POST','/v1/sandbox/deposit',{'asset':'USD','amount_minor':3500},token,'same-key')
        self.assertEqual(code,409); self.assertIn('different request',body['message'])
    def test_sandbox_trade_does_not_claim_execution(self):
        _, reg = self.request('POST','/v1/auth/register',{'email':'trade@example.com','password':'Long-Enough-Password-77'})
        code, body = self.request('POST','/v1/sandbox/trade',{'asset':'BTC','amount_minor':123},token=reg['access_token'],idem='trade-intent-1')
        self.assertEqual(code,201); self.assertEqual(body['status'],'simulated'); self.assertFalse(body['live_money'])
    def test_live_operation_hard_blocked(self):
        _, reg = self.request('POST','/v1/auth/register',{'email':'blocked@example.com','password':'Long-Enough-Password-77'})
        code, body = self.request('POST','/v1/live/deposit',{'amount_minor':100},token=reg['access_token'])
        self.assertEqual(code,423); self.assertEqual(body['error'],'LIVE_MONEY_DISABLED')
        for path in ('/v1/orders/crypto','/v1/private-market/subscriptions','/v1/money-movement/withdrawals','/v1/crypto/deposits'):
            code, body = self.request('POST',path,{'amount_minor':100},token=reg['access_token'])
            self.assertEqual(code,423, path); self.assertEqual(body['error'],'LIVE_MONEY_DISABLED',path)
    def test_auth_required(self):
        code, _ = self.request('GET','/v1/ledger'); self.assertEqual(code,401)
    def test_bad_asset_rejected(self):
        _, reg = self.request('POST','/v1/auth/register',{'email':'asset@example.com','password':'Long-Enough-Password-77'})
        code, _ = self.request('POST','/v1/sandbox/deposit',{'asset':'DOGE','amount_minor':100},token=reg['access_token'],idem='bad-asset')
        self.assertEqual(code,400)

if __name__ == '__main__': unittest.main(verbosity=2)
