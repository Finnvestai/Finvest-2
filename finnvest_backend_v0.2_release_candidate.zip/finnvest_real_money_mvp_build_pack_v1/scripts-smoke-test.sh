#!/usr/bin/env sh
set -eu
BASE_URL="${BASE_URL:-http://127.0.0.1:8080}"
python - "$BASE_URL" <<'PY'
import json, sys, urllib.request
base=sys.argv[1]
with urllib.request.urlopen(base.rstrip('/')+'/health', timeout=3) as response:
    data=json.loads(response.read())
assert response.status == 200, response.status
assert data.get('mode') == 'simulation-only', data
assert data.get('status') == 'ok', data
print('Finnvest smoke test: PASS —', data)
PY
