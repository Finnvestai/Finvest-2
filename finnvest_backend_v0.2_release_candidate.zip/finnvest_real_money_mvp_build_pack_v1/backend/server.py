"""Finnvest Backend v0.2 — simulation-only reference implementation.
Uses Python standard library only. Not for production custody or real-money activity.
"""
from __future__ import annotations
import hashlib, hmac, json, os, secrets, sqlite3, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from contextlib import contextmanager
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = Path(os.environ.get("FINNVEST_DB", ROOT / "data" / "finnvest.sqlite3"))
FLAGS_PATH = ROOT / "config" / "feature-flags.json"
MAX_BODY = 64 * 1024


def flags():
    try: return json.loads(FLAGS_PATH.read_text())
    except Exception: return {"real_money": {"enabled": False}}


@contextmanager
def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)
    db.row_factory = sqlite3.Row
    try:
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA journal_mode=WAL")
        yield db
    finally:
        db.close()


def init_db():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
          password_salt TEXT NOT NULL, created_at INTEGER NOT NULL,
          kyc_status TEXT NOT NULL DEFAULT 'not_started', jurisdiction TEXT,
          account_status TEXT NOT NULL DEFAULT 'active'
        );
        CREATE TABLE IF NOT EXISTS sessions (
          token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          expires_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS ledger_accounts (
          id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), asset TEXT NOT NULL,
          account_type TEXT NOT NULL, UNIQUE(user_id, asset, account_type)
        );
        CREATE TABLE IF NOT EXISTS journal_entries (
          id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), kind TEXT NOT NULL,
          status TEXT NOT NULL, idempotency_key TEXT NOT NULL, created_at INTEGER NOT NULL,
          metadata TEXT NOT NULL DEFAULT '{}', UNIQUE(user_id, idempotency_key)
        );
        CREATE TABLE IF NOT EXISTS postings (
          id INTEGER PRIMARY KEY AUTOINCREMENT, entry_id TEXT NOT NULL REFERENCES journal_entries(id),
          account_id TEXT NOT NULL REFERENCES ledger_accounts(id), amount_minor INTEGER NOT NULL,
          asset TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_events (
          id TEXT PRIMARY KEY, user_id TEXT, event_type TEXT NOT NULL, created_at INTEGER NOT NULL,
          details TEXT NOT NULL
        );
        ''')


def audit(db, user_id, event_type, details):
    db.execute("INSERT INTO audit_events VALUES(?,?,?,?,?)",
      (secrets.token_hex(16), user_id, event_type, int(time.time()), json.dumps(details, separators=(',', ':'))))


def password_hash(password, salt):
    return hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1).hex()


def public_user(row):
    return {"id": row["id"], "email": row["email"], "kyc_status": row["kyc_status"],
            "jurisdiction": row["jurisdiction"], "account_status": row["account_status"], "created_at": row["created_at"]}

class APIError(Exception):
    def __init__(self, status, message): self.status, self.message = status, message

class Handler(BaseHTTPRequestHandler):
    server_version = "Finnvest-SimAPI/0.2"
    def log_message(self, fmt, *args):
        # Avoid logging credentials, tokens, request bodies, or personal data.
        if os.environ.get("FINNVEST_ACCESS_LOG") == "1": super().log_message(fmt, *args)

    def send_json(self, status, obj):
        raw = json.dumps(obj, separators=(',', ':')).encode()
        self.send_response(status); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw))); self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff"); self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers(); self.wfile.write(raw)

    def body(self):
        try: n = int(self.headers.get("Content-Length", "0"))
        except ValueError: raise APIError(400, "Invalid Content-Length")
        if n < 0 or n > MAX_BODY: raise APIError(413, "Request body too large")
        try: value = json.loads(self.rfile.read(n) or b"{}")
        except (json.JSONDecodeError, UnicodeDecodeError): raise APIError(400, "Invalid JSON body")
        if not isinstance(value, dict): raise APIError(400, "JSON body must be an object")
        return value

    def auth(self, db):
        header = self.headers.get("Authorization", "")
        if not header.startswith("Bearer "): raise APIError(401, "Bearer token required")
        token = header[7:].strip()
        if not token or len(token) > 256: raise APIError(401, "Invalid session")
        row = db.execute("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?",
                         (hashlib.sha256(token.encode()).hexdigest(), int(time.time()))).fetchone()
        if not row or row["account_status"] != "active": raise APIError(401, "Session invalid or expired")
        return row

    def do_GET(self): self.dispatch()
    def do_POST(self): self.dispatch()
    def do_OPTIONS(self): self.send_response(204); self.send_header("Allow", "GET, POST, OPTIONS"); self.end_headers()

    def dispatch(self):
        try:
            path = urlparse(self.path).path
            if path.startswith("/") and ".." in path.split("/"): raise APIError(400, "Invalid path")
            with connect() as db:
                if self.command == "GET" and path == "/health":
                    return self.send_json(200, {"status":"ok", "mode":"simulation-only", "version":"0.2.0"})
                if self.command == "POST" and path == "/v1/auth/register": return self.register(db)
                if self.command == "POST" and path == "/v1/auth/login": return self.login(db)
                if self.command == "GET" and path == "/v1/me":
                    return self.send_json(200, {"user": public_user(self.auth(db))})
                if self.command == "GET" and path == "/v1/eligibility":
                    user = self.auth(db)
                    return self.send_json(200, {"eligible": False, "reason_codes":["KYC_NOT_VERIFIED", "JURISDICTION_NOT_APPROVED", "PRODUCT_APPROVAL_MISSING"], "kyc_status":user['kyc_status'], "real_money_enabled":False})
                if self.command == "GET" and path == "/v1/ledger": return self.ledger(db)
                if self.command == "POST" and path in ("/v1/sandbox/deposit", "/v1/sandbox/trade", "/v1/sandbox/private-market/subscribe"):
                    return self.sandbox(db, path)
                protected_live_paths = {
                    "/v1/orders/crypto", "/v1/private-market/subscriptions",
                    "/v1/money-movement/withdrawals", "/v1/money-movement/deposits",
                    "/v1/crypto/deposits", "/v1/crypto/withdrawals", "/v1/custody/transfers",
                    "/v1/private-market/redemptions"
                }
                if self.command == "POST" and (path.startswith("/v1/live/") or path in protected_live_paths):
                    audit(db, None, "live_operation_blocked", {"path":path})
                    return self.send_json(423, {"error":"LIVE_MONEY_DISABLED", "message":"Live-money operations are disabled in this build."})
                raise APIError(404, "Route not found")
        except APIError as e: self.send_json(e.status, {"error":"REQUEST_REJECTED", "message":e.message})
        except (BrokenPipeError, ConnectionResetError): pass
        except Exception:
            # Keep internals and database errors out of client responses.
            self.send_json(500, {"error":"INTERNAL_ERROR", "message":"Request could not be completed."})

    def register(self, db):
        data = self.body(); email = str(data.get("email", "")).strip().lower(); password = data.get("password", "")
        if len(email) > 254 or "@" not in email or len(email) < 3: raise APIError(400, "A valid email is required")
        if not isinstance(password, str) or len(password) < 12 or len(password) > 1024: raise APIError(400, "Password must be 12–1024 characters")
        salt = secrets.token_hex(16); uid = secrets.token_hex(16); now = int(time.time())
        try:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO users(id,email,password_hash,password_salt,created_at) VALUES(?,?,?,?,?)", (uid,email,password_hash(password,salt),salt,now))
            for asset in ("USD", "BTC", "ETH", "PRIVATE_MARKET_UNITS"):
                db.execute("INSERT INTO ledger_accounts(id,user_id,asset,account_type) VALUES(?,?,?,'customer_available')", (secrets.token_hex(16),uid,asset))
            audit(db, uid, "account_registered", {"email_domain":email.rsplit('@',1)[1]})
            db.execute("COMMIT")
        except sqlite3.IntegrityError:
            db.execute("ROLLBACK"); raise APIError(409, "Account could not be created with those details")
        token = secrets.token_urlsafe(32); th = hashlib.sha256(token.encode()).hexdigest()
        db.execute("INSERT INTO sessions VALUES(?,?,?)", (th,uid,now+3600))
        row = db.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
        return self.send_json(201, {"user":public_user(row), "access_token":token, "token_type":"Bearer", "expires_in":3600, "mode":"simulation-only"})

    def login(self, db):
        data = self.body(); email = str(data.get("email", "")).strip().lower(); password = data.get("password", "")
        row = db.execute("SELECT * FROM users WHERE email=?",(email,)).fetchone()
        # A fixed dummy scrypt operation reduces the timing gap for unknown accounts.
        if not row:
            password_hash(str(password)[:1024], "00"*16)
            raise APIError(401, "Invalid email or password")
        if not isinstance(password,str) or not hmac.compare_digest(password_hash(password,row['password_salt']), row['password_hash']): raise APIError(401, "Invalid email or password")
        token = secrets.token_urlsafe(32); now = int(time.time())
        db.execute("INSERT INTO sessions VALUES(?,?,?)",(hashlib.sha256(token.encode()).hexdigest(),row['id'],now+3600))
        audit(db,row['id'],"login_succeeded",{})
        return self.send_json(200,{"user":public_user(row),"access_token":token,"token_type":"Bearer","expires_in":3600,"mode":"simulation-only"})

    def ledger(self, db):
        user = self.auth(db)
        accounts = db.execute("SELECT id,asset,account_type FROM ledger_accounts WHERE user_id=?",(user['id'],)).fetchall()
        result=[]
        for a in accounts:
            if a['account_type'] != 'customer_available':
                continue
            bal = db.execute("SELECT COALESCE(SUM(p.amount_minor),0) n FROM postings p JOIN journal_entries j ON j.id=p.entry_id WHERE p.account_id=? AND j.status='posted'",(a['id'],)).fetchone()['n']
            result.append({"asset":a['asset'],"account_type":a['account_type'],"balance_minor_units":bal})
        return self.send_json(200,{"balances":result,"source":"double-entry ledger","mode":"simulation-only"})

    def sandbox(self, db, path):
        user = self.auth(db); data = self.body(); idem = str(self.headers.get("Idempotency-Key", "")).strip()
        if not idem or len(idem)>128: raise APIError(400, "Idempotency-Key header required (1–128 characters)")
        kind = {"/v1/sandbox/deposit":"sandbox_deposit", "/v1/sandbox/trade":"sandbox_trade", "/v1/sandbox/private-market/subscribe":"sandbox_private_market_subscription"}[path]
        asset = str(data.get("asset", "USD")).upper()
        try: amount = int(data.get("amount_minor", 0))
        except (ValueError, TypeError): raise APIError(400,"amount_minor must be a positive integer")
        existing = db.execute("SELECT id,kind,status,metadata FROM journal_entries WHERE user_id=? AND idempotency_key=?",(user['id'],idem)).fetchone()
        if existing:
            old = json.loads(existing['metadata'])
            if existing['kind'] != kind or old.get('asset') != asset or old.get('amount_minor') != amount:
                raise APIError(409, "Idempotency key reused with a different request")
            return self.send_json(200,{"entry_id":existing['id'],"kind":existing['kind'],"status":existing['status'],"idempotent_replay":True,"mode":"simulation-only"})
        if asset not in ("USD","BTC","ETH","PRIVATE_MARKET_UNITS"): raise APIError(400,"Unsupported simulation asset")
        if amount <= 0 or amount > 100_000_000_000: raise APIError(400,"amount_minor outside permitted simulation range")
        if path.endswith("/deposit") and asset not in ("USD",): raise APIError(400,"Sandbox fiat deposits use USD in this prototype")
        # This is a simulation ledger only: no external provider or blockchain call exists.
        entry_id=secrets.token_hex(16); now=int(time.time())
        try:
            db.execute("BEGIN IMMEDIATE")
            acct=db.execute("SELECT id FROM ledger_accounts WHERE user_id=? AND asset=?",(user['id'],asset)).fetchone()
            if not acct: raise APIError(400,"Ledger account unavailable")
            db.execute("INSERT INTO journal_entries(id,user_id,kind,status,idempotency_key,created_at,metadata) VALUES(?,?,?,'posted',?,?,?)",(entry_id,user['id'],kind,idem,now,json.dumps({"asset":asset,"amount_minor":amount,"simulation":True})))
            # Two balanced postings. Sandbox clearing is a system-side account represented by a null-free internal account.
            clearing_id="sandbox-clearing-"+asset
            db.execute("INSERT OR IGNORE INTO ledger_accounts(id,user_id,asset,account_type) VALUES(?,?,?,'sandbox_clearing')",(clearing_id,user['id'],asset))
            if path.endswith("/deposit"):
                db.execute("INSERT INTO postings(entry_id,account_id,amount_minor,asset) VALUES(?,?,?,?)",(entry_id,acct['id'],amount,asset))
                db.execute("INSERT INTO postings(entry_id,account_id,amount_minor,asset) VALUES(?,?,?,?)",(entry_id,clearing_id,-amount,asset))
            else:
                # Sandbox trade/subscription is recorded as a simulated intent and is not reflected as a funded asset balance.
                db.execute("UPDATE journal_entries SET status='simulated' WHERE id=?",(entry_id,))
            audit(db,user['id'],kind,{"entry_id":entry_id,"asset":asset,"amount_minor":amount,"simulation":True})
            db.execute("COMMIT")
        except APIError:
            db.execute("ROLLBACK"); raise
        except sqlite3.IntegrityError:
            db.execute("ROLLBACK"); raise APIError(409,"Idempotency key already used")
        return self.send_json(201,{"entry_id":entry_id,"kind":kind,"status":"posted" if path.endswith('/deposit') else "simulated","simulation":True,"live_money":False})


def main():
    init_db(); host=os.environ.get("FINNVEST_HOST","127.0.0.1"); port=int(os.environ.get("PORT","8080"))
    print(f"Finnvest simulation API listening on http://{host}:{port}; live money disabled")
    ThreadingHTTPServer((host,port),Handler).serve_forever()

if __name__ == "__main__": main()
