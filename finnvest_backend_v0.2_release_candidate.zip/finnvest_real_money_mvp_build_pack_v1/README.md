# Finnvest Backend v0.2 — Simulation-only release candidate

Finnvest is a responsive web and mobile investment platform concept for cryptoassets and alternative investments/private markets. This repository snapshot adds a runnable Python API, persistent SQLite development store, session-based authentication, a double-entry simulation ledger, server-side eligibility defaults, sandbox transaction routes, tests, and a Docker image definition.

## Status and release boundary

**This is a simulation-only release candidate, not a production-ready regulated financial service.** No live deposits, withdrawals, crypto execution, custody transfers, private-market subscriptions or redemptions are implemented or enabled. All live-money feature flags are false. The `/v1/live/*` namespace fails closed with `423 LIVE_MONEY_DISABLED`.

Do not use real customer data, real assets, real provider credentials or real funds. Do not expose the development server directly to the public internet. The standard-library HTTP server and SQLite are for local evaluation only; production requires a hardened application server, managed PostgreSQL, secrets management, rate limiting, MFA, external identity/KYC/AML providers, monitoring, backups, privacy review, security testing, and jurisdiction-specific legal and operational approvals.

## Quick start

Requirements: Python 3.11+ (tested on Python 3.12; no third-party runtime dependencies).

```bash
python -m unittest discover -s tests -v
python backend/server.py
```

Then open `http://127.0.0.1:8080/health`. The default host is loopback-only. Set `FINNVEST_DB=/path/to/dev.sqlite3` to choose the local database path. The responsive shell is `apps/web/index.html`.

## Implemented API

- `GET /health` — simulation mode and version.
- `POST /v1/auth/register` — account creation; minimum 12-character password.
- `POST /v1/auth/login` — returns a one-hour opaque bearer token.
- `GET /v1/me` — authenticated account profile.
- `GET /v1/eligibility` — fails closed until KYC, jurisdiction and product approval are in place.
- `GET /v1/ledger` — balances from posted ledger entries.
- `POST /v1/sandbox/deposit` — USD-only simulated deposit, requires `Idempotency-Key`.
- `POST /v1/sandbox/trade` — simulated intent only, requires `Idempotency-Key`.
- `POST /v1/sandbox/private-market/subscribe` — simulated intent only, requires `Idempotency-Key`.
- `POST /v1/live/*` — hard-disabled, returns HTTP 423.

Sandbox amounts are integer minor units (for example USD cents). Sandbox routes do not call payment providers, exchanges, custodians, blockchains or private-market venues.

## Validation performed

The current test suite covers health, registration/login, authenticated profile, fail-closed eligibility, password minimum, unauthenticated access rejection, sandbox idempotency, balanced double-entry postings, unsupported assets, and live-operation blocking. Run tests before every change. Passing these tests is not equivalent to an independent security review or production approval.

## Release checklist

See `docs/24-hour-release-plan.md`, `docs/compliance-control-matrix.md`, `docs/security-and-operations.md` and `docs/acceptance-tests.md`. A public demo may publish only with clearly marked simulated data and no real-money controls. Production financial operations require independent sign-off and separate implementation.
