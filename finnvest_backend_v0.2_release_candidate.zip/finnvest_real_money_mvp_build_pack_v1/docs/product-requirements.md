# Product Requirements — Finnvest Real-Money-Ready MVP

## Product
Finnvest is a responsive web and native mobile investment platform concept supporting:
- Cryptoassets (spot-only as the initial baseline; no leverage, derivatives, lending or staking unless separately reviewed and approved).
- Alternative investments/private markets (funds, private credit, private equity or other offerings only after product-by-product legal classification and distribution review).
- Global expansion via market-by-market enablement, not blanket worldwide availability.

## Primary user journeys
1. Discover product categories and read risk/fee/liquidity disclosures.
2. Create an account; verify email/phone; complete identity and residence checks.
3. Complete risk, appropriateness/suitability and investor-classification steps when applicable.
4. View eligible products based on country, investor status and product restrictions.
5. Review order/subscription terms, total fees, execution/valuation methodology, cancellation rules and expected settlement.
6. Submit a transaction only when the relevant market, product, account and partner controls permit it.
7. See pending/settled/failed/reversed status, statements, transaction history and support options.
8. Request withdrawals/redemptions only when the asset, provider, lockup and legal terms allow them.

## MVP boundaries
- Responsive web application and mobile-ready API; native iOS and Android clients can use the same API.
- Cryptoasset and private-market product catalog with explicit product type, issuer/provider, jurisdiction availability, liquidity, lockups, valuation timestamp, fees and risk disclosures.
- Account profile, identity/compliance case status, watchlist, portfolio views, transaction timeline, downloadable statements and support/complaints intake.
- Admin operations console must have role-based access, maker-checker approval for sensitive actions, and auditable changes.
- No social trading, leverage, derivatives, unsecured lending, yield promises, or automated personalized recommendations in the initial scope.

## Market availability
Every product and action must be checked server-side against:
- User residence and current location where legally relevant.
- Entity and licence/permission scope.
- Investor classification and eligibility.
- Product/issuer offering restrictions.
- Provider/custody/payment rail availability.
- Sanctions and financial-crime controls.
- Local disclosure, marketing and consumer-protection requirements.

## UX principles
Accessible, plain-language, responsive, transparent about uncertainty, fees, custody, settlement, liquidity and loss risk. No fake urgency, guaranteed-return claims or misleading regulatory badges.
