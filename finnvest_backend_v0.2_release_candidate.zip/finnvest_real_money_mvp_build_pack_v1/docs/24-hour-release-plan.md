# 24-hour release plan — Finnvest v0.2

This is a time-boxed candidate plan, not a promise that regulatory or production approval can be completed in 24 hours. Owners must be assigned by the project lead; no external specialist or agent is presumed to have completed a task unless evidence is attached.

## Workstream A — Authentication and accounts
- [x] Register/login API; opaque random bearer token; one-hour expiry.
- [x] Password hashing via Python `scrypt`; duplicate email rejection.
- [ ] Before production: MFA/passkeys, rate limiting, password reset, session revocation, abuse detection, email verification, threat review.

## Workstream B — Persistence and ledger
- [x] SQLite development persistence and ledger/account schema.
- [x] Double-entry balanced postings for simulated USD deposit.
- [x] Idempotency key replay protection, including mismatch rejection.
- [ ] Before production: managed PostgreSQL, migrations, per-asset precision policy, immutable ledger controls, concurrent/idempotency stress tests, daily reconciliation, backups and restore drill.

## Workstream C — Eligibility and compliance
- [x] Server-side eligibility response fails closed by default.
- [x] Live-money route namespace hard-blocked.
- [ ] Before production: approved legal entity/permissions, jurisdiction-by-jurisdiction rules, KYC/AML/sanctions/PEP integrations, investor classification, product suitability/appropriateness where required, complaints and regulatory reporting workflows.

## Workstream D — Sandbox provider adapters
- [x] Simulation-only deposit, crypto-trade intent and private-market subscription intent endpoints.
- [x] No real provider, exchange, custodian or blockchain integration is invoked.
- [ ] Before production: choose approved providers; sandbox credentials; signed webhook verification and replay protection; settlement/reconciliation state machines; failure, timeout and compensation tests; partner approval evidence.

## Workstream E — Automated tests and release gates
- [x] Standard-library automated test suite and GitHub Actions workflow.
- [x] Dockerfile for repeatable packaging; local health check.
- [ ] Before public demo: clean-environment smoke test, container scan, dependency/image scan, accessibility and mobile viewport QA, privacy/terms review, demo-only copy, staging deployment and rollback drill.
- [ ] Before real-money production: independent penetration test, no unresolved critical/high findings, operations/incident-response sign-off, legal/compliance sign-off, provider sign-off, approved release evidence and independent release approval.

## Suggested timeline
- Hours 0–4: freeze requirements, assign owners, run tests, review public demo copy.
- Hours 4–10: security/code review, edge cases, API contract reconciliation, responsive accessibility checks.
- Hours 10–16: staging container build, smoke test, logs/monitoring and rollback verification.
- Hours 16–20: legal/compliance review of demo claims and market availability; confirm all live flags off.
- Hours 20–24: release-candidate decision, publish only the simulation demo if checks pass, record evidence and rollback owner.

## Go/no-go rules
- **Demo candidate:** may proceed only if automated tests pass, no secrets or real customer data are included, the UI says simulation/demo, and all live-money routes remain disabled.
- **Production financial service:** no-go until every relevant item in the compliance and operations matrices has signed evidence. This repository is not sufficient for that release.
