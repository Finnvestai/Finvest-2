# Compliance and Launch Control Matrix

This is a control-planning checklist, not legal advice or a determination that any particular licence is required. Requirements vary by entity, service, product and customer location. Obtain qualified local advice and confirm requirements with the relevant authorities.

| Control area | Evidence required before enabling relevant capability | Owner |
|---|---|---|
| Entity and permissions | Legal entity, service-by-service regulatory analysis, verified authorisations/registrations and approved scope | Legal / Compliance |
| Country availability | Written country-by-country launch matrix covering marketing, onboarding, execution, custody and distribution | Legal / Compliance |
| Cryptoassets | Asset listing review, provider permissions, custody model, execution venue review, disclosures and transfer controls | Compliance / Product |
| Private markets | Offering classification, prospectus/private placement analysis, investor eligibility, marketing restrictions, transfer/lockup rules and approved documents | Legal / Compliance |
| AML/CFT | Risk assessment, customer due diligence, sanctions/PEP screening, monitoring, escalation, reporting and record retention as applicable | MLRO / Compliance |
| Investor protection | Risk disclosures, suitability/appropriateness where required, complaints, conflicts, fee transparency and fair treatment | Compliance / Product |
| Custody/client assets | Legal ownership/segregation analysis, reconciliation, access governance, insolvency treatment and independent assurance | Legal / Operations |
| Payments | Approved regulated payment partner, contracts, safeguarding/settlement model, chargeback/fraud controls and reconciliation | Treasury / Legal |
| Data protection | Data map, lawful basis, retention, rights handling, cross-border transfers and processor agreements | Privacy / Security |
| Security | Threat model, secure SDLC, penetration test, key management, incident response and recovery tests | Security |
| Finance/operations | Double-entry ledger, daily reconciliation, exception handling, finance controls and audited reports as required | Finance / Operations |
| Governance | Named control owners, board/management approvals, change control, training and evidence repository | Executive / Compliance |

## Release gate
No live-money capability is enabled until each relevant row has a dated evidence reference, named accountable approver, expiry/review date and scope that matches the exact legal entity, product, market and provider. An approval for one product or country does not automatically permit another.
