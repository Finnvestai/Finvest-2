# Release status — 26 October 2026

## Current status
**Candidate build only.** Local automated tests pass. This status does not claim that a public URL is deployed, that mobile app binaries exist, or that an external security, compliance or legal review has been completed.

## Evidence in this package
- Automated API tests: 9 passing in the local Python 3.13 runtime.
- Python compilation: passed.
- Real-money feature flags: all false.
- API health mode: simulation-only.
- Dockerfile and Compose file supplied, but container build/deploy is not asserted unless executed in the target environment.

## Remaining before a public demo
- [ ] Choose and connect a repository/hosting account and target domain.
- [ ] Run CI in the target repository and build the container in a clean environment.
- [ ] Run `scripts-smoke-test.sh` against staging.
- [ ] Review all copy, screenshots and disclosures to ensure demo-only language is unambiguous.
- [ ] Run accessibility, browser/device and container/security checks.
- [ ] Confirm no production secrets or customer data are present.
- [ ] Confirm rollback and incident contact.

## Remaining before a real-money production launch
See the compliance, security, architecture and acceptance-test documents. All relevant authorisations, partner approvals, market/product eligibility, security testing, custody/payment design, ledger reconciliation and operations sign-offs must be evidenced before any real-money capability can be enabled. This candidate does not implement those production integrations.
