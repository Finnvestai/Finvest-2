# Security and Operational Requirements

## Minimum baseline
- Strong authentication, MFA/step-up authentication for sensitive actions, secure session management and account recovery protections.
- RBAC/ABAC, least privilege, privileged access reviews and maker-checker for high-risk operations.
- TLS in transit, managed encryption at rest, centrally managed secrets and key rotation; never commit secrets.
- Secure SDLC, dependency/SBOM scanning, SAST/DAST, code review, signed releases and environment separation.
- Webhook signature validation, replay protection, idempotency and rate limiting.
- Immutable audit logs for authentication, eligibility decisions, disclosures, orders, admin actions and gate changes.
- PII minimisation, redaction in logs, retention/deletion policy and restricted support access.
- Monitoring for account takeover, fraud, sanctions alerts, transaction anomalies, ledger breaks, provider outages and reconciliation failures.
- Incident response, breach notification assessment, business continuity, tested backups and disaster recovery.
- Independent penetration test and remediation sign-off before launch.

## Financial integrity
- Daily (or more frequent as risk requires) reconciliation of bank/payment/custody/execution/administrator records to the internal ledger.
- Alerts for unbalanced postings, duplicate events, unexplained asset shortfalls, stuck states and aged exceptions.
- No manual balance editing. Corrections use approved compensating entries with dual control.
- Provider downtime must stop new actions safely; never report a transaction as settled based only on a client redirect.

## Operations
- Runbooks for account freeze, compromised credentials, erroneous trades, payment reversals, crypto transfer incidents, provider outages, ledger discrepancies, data incidents and customer complaints.
- Clear escalation path to compliance and named incident commander.
- Regular access recertification and tabletop exercises.
