# Acceptance Criteria and Test Plan

## Functional
- Product catalog shows product type, eligibility, risk, fees, liquidity, valuation timestamp and provider/issuer information.
- Eligibility is evaluated server-side for every product and every transaction request.
- Order and subscription state machines reject invalid transitions.
- Idempotency prevents duplicate order, deposit, withdrawal and subscription requests.
- Ledger postings balance for each asset/currency; corrections are compensating entries.
- Provider webhooks validate signatures, reject replay, and tolerate duplicate delivery.
- User can view pending/settled/failed states and downloadable transaction statements.
- Admin actions are role-controlled and auditable; high-risk actions require maker-checker.

## Negative tests (must pass)
- All live-money gates off: all money movement and execution endpoints return a safe disabled response.
- Missing compliance evidence, expired approval, unknown country, unapproved asset or unhealthy provider: fail closed.
- Client-side feature flag manipulation cannot enable any capability.
- Ineligible private-market investor cannot subscribe even if UI requests it.
- Duplicate provider webhook does not create duplicate ledger postings.
- Unbalanced journal transaction is rejected.
- A provider redirect alone cannot mark a payment or trade as settled.
- Withdrawal to a blocked/high-risk address is rejected or held for reviewed escalation according to policy.

## Security and operations
- MFA and recovery abuse tests; authorization boundary tests; rate-limit tests; secret scanning; dependency checks.
- Penetration test with no unresolved critical/high findings before production approval.
- Restore from backup and disaster-recovery exercise.
- Reconciliation exception and provider outage tabletop.
- Accessibility tests against WCAG 2.2 AA target; responsive tests across common mobile/desktop viewports.

## Release criterion
All applicable tests pass, evidence is retained, security/compliance/operations approve the exact release scope, and only specifically approved market/product/provider gates are enabled.

## Backend v0.2 tests actually present
The repository's `tests/test_api.py` currently checks health/mode, registration/login/profile, fail-closed eligibility, short-password rejection, authenticated access, balanced sandbox deposit postings, idempotent replay and payload-mismatch rejection, invalid asset rejection, sandbox trade intent semantics, and hard-blocked live endpoints. The broader controls above remain requirements rather than implemented functionality; do not interpret this limited suite as a production certification.
