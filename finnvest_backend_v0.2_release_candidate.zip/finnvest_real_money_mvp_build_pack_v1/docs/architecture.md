# Reference Architecture

## Components
- Web client and native iOS/Android clients: presentation only; no authoritative financial state.
- API gateway/BFF: authentication, rate limits, request validation, idempotency and authorization.
- Identity & compliance service: KYC/KYB, beneficial ownership, sanctions/PEP screening, source-of-funds/source-of-wealth where required, investor categorisation and case management.
- Product and eligibility service: product metadata, offering documents, jurisdiction rules, investor limits, dealing windows, lockups and transfer restrictions.
- Order/subscription service: crypto order intents and private-market subscription/redemption requests; explicit state machines.
- Provider adapters: approved payment institution, custodian, broker/exchange, transfer agent/fund administrator, pricing and identity vendors. Provider integrations require approved contracts and sandbox/production certification.
- Double-entry ledger: append-only journal, balanced postings, account segregation, reconciliation and controlled corrections.
- Portfolio and reporting service: derives holdings from reconciled ledger/provider records; displays timestamps and valuation methodology.
- Risk/fraud monitoring: velocity controls, anomaly detection, transaction monitoring, case escalation and freeze controls.
- Admin and audit: least privilege, maker-checker, immutable events, exportable evidence and break-glass procedures.
- Observability: metrics, structured logs without secrets, alerting, incident runbooks and disaster recovery.

## Financial state and ledger
- Use integer minor units for fiat; use fixed-precision decimal or integer base units for cryptoassets. Never use binary floating point for money.
- Every posting is double-entry and balanced per currency/asset.
- Ledger entries are append-only. Corrections are compensating entries, never silent edits.
- Provider callbacks are authenticated, idempotent and reconciled against provider statements.
- Client-visible balances are derived views; the ledger and reconciled custody/provider records are authoritative.
- Separate available, reserved, pending, settled, locked and withdrawable balances.

## Cryptoasset flow
1. Validate user, jurisdiction, asset, order size, limits and disclosures.
2. Confirm custody and execution providers are approved for this entity and market.
3. Reserve funds atomically; use idempotency keys.
4. Submit to execution provider; persist provider IDs and state transitions.
5. Reconcile fills, fees, settlement and custody movements.
6. Release/adjust reservations and notify user.
7. Apply withdrawal address screening, sanctions/risk checks, cooling-off or step-up authentication where required, and provider policy controls.

## Private-market flow
1. Validate offering status, target market, investor classification, eligibility, concentration/limit rules and required documents.
2. Present offering memorandum, subscription agreement, valuation policy, fees, risks, lockups and redemption/transfer limitations.
3. Capture affirmative acceptance and document version/hash.
4. Submit subscription request; track pending/accepted/rejected/allocated/settled states.
5. Reconcile cash movement and issuer/administrator allocation confirmation.
6. Reflect valuation with source and as-of date; never imply daily liquidity where none exists.
7. Redemptions/transfers are subject to offering documents, lockups, gates and applicable rules.

## Feature gate design
- All real-money capabilities default false in config and are enforced server-side.
- Gate evaluation requires: environment is production, compliance sign-off reference exists, jurisdiction/product allowlist exists, approved provider configuration is healthy, and two-person release approval is recorded.
- Fail closed if any evidence is absent, stale or contradictory.
- Separate gates for fiat deposits, fiat withdrawals, crypto deposits, crypto withdrawals, crypto execution, private-market subscriptions, private-market redemptions, custody transfer and each market/product.
- Do not use a single global boolean as the only control.
