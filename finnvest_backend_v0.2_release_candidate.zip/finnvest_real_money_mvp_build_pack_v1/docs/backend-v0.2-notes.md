# Backend v0.2 implementation notes

- Runtime: Python standard library HTTP server, SQLite in WAL mode, local opaque bearer sessions.
- Password storage: `scrypt` with per-user random salt. This is a prototype; production should use a mature identity provider, MFA/passkeys, throttling and session revocation.
- Ledger: integer minor-unit amounts, journal entries and postings. Sandbox deposits produce two equal/opposite postings. Sandbox trade and private-market subscription endpoints record simulated intent only and do not settle or move balances.
- Eligibility: intentionally returns ineligible by default; it is a placeholder and not a legal rules engine.
- Real-money: all config flags false; all `/v1/live/*` routes return 423. No provider or blockchain calls are implemented.
- Data: the local SQLite database stores account and simulation records. Do not use real personal data. Use synthetic data only.
- Logging: request bodies, tokens and credentials are not logged by default. Operational logging, monitoring and privacy controls still need production design.
- Concurrency: idempotency uniqueness is enforced by the database; load/stress testing remains required.
